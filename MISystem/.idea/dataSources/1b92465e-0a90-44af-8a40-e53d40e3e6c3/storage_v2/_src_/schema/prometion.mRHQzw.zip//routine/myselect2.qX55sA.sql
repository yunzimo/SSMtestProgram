create
    definer = root@localhost function myselect2() returns int
    return 666;

