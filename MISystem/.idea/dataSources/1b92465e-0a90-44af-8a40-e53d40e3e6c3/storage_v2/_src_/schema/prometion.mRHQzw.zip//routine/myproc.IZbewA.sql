create
    definer = root@localhost procedure myproc()
BEGIN
   SELECT COUNT(*) FROM test;
  END;

