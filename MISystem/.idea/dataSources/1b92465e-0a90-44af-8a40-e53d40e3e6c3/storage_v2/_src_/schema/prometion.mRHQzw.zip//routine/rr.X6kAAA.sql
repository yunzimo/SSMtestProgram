create
    definer = root@localhost procedure rr()
BEGIN
        SELECT COUNT(*) FROM dept;
    END;

