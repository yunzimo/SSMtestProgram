create
    definer = root@localhost function myselect3() returns int
begin 
    declare c int;
    select id from class where cname="python" into c;
    return c;
end;

