create
    definer = root@localhost procedure dada(OUT s int)
begin
select count(*) into s from mysql.user;
end;

