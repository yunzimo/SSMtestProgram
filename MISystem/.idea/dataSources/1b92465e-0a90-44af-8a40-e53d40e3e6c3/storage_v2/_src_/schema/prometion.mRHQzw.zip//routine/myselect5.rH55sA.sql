create
    definer = root@localhost function myselect5() returns int
begin 
    declare c int;
    select id from department where name="铂金队" into c;
    return c;
end;

