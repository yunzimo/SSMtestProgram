create
    definer = root@localhost procedure dede()
begin
select count(*)from dept;
end;

