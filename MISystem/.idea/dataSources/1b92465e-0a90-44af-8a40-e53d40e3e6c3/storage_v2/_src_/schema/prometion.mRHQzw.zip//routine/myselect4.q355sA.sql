create
    definer = root@localhost function myselect4() returns int
begin 
    declare c int;
    select id from department where cname="铂金队" into c;
    return c;
end;

