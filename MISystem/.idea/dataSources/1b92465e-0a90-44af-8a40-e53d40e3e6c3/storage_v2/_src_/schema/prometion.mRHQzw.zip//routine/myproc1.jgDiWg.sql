create
    definer = root@localhost procedure myproc1()
BEGIN
   SELECT COUNT(*) FROM dept;
  END;

